class tests:

    def test(self):
        assert True
        