def function():
    print('This is a practice project!')
